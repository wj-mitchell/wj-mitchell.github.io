<!-- ---
layout: default
title: Teaching
nav_order: 3
---

# Lectures
## Developmental Psychology Course
### 14 Lectures Recorded in Summer 2022
<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?list=PLNDTMgEsZTb456EACnAiQ0EgNr9dvpZre" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe> -->